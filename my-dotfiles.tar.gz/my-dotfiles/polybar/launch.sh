#!/usr/bin/env bash

    # Terminate already running bar instances
    killall -q polybar

    # Wait until the processes have been shut down
    while pgrep -u $UID -x polybar >/dev/null; do sleep 1; done

    # Launch Polybar, using main bar configuration
    # REPLACE "example" with the actual name of your bar from config.ini
    polybar example &
    ```
    *(Note: If your bar in `config.ini` is named `[bar/mybar]`, change `example` to `mybar`).*

3.  **Make it executable:**
    ```bash
    chmod +x ~/.config/polybar/launch.sh
    ```

---

### 2. Add it to i3 Config
Now, tell i3 to run that script whenever it starts or restarts.

1.  **Open your i3 config:**
    ```bash
    nano ~/.config/i3/config
    ```
2.  **Add this line at the very bottom:**
    ```bash
    exec_always --no-startup-id ~/.config/polybar/launch.sh
    ```

---

### 3. Disable the Default i3 Bar
Since you’re using Polybar, you probably want to hide the "stock" i3 bar (the one that usually sits at the bottom).

Find the section in your `~/.config/i3/config` that looks like this and **comment it out** (add `#` to every line):
```bash
# bar {
#     status_command i3status
# }
