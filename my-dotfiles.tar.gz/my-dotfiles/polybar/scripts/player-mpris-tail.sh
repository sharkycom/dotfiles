#!/bin/bash

# Fast, continuous tracking loop
playerctl metadata --format '{{ status }} : {{ artist }} - {{ title }}' --follow 2>/dev/null | while read -r line; do
    status=$(echo "$line" | cut -d ' ' -f 1)
    title=$(echo "$line" | cut -d ':' -f 2- | sed -E 's/\([0-9]+\)//g; s/ - YouTube//g; s/ - Spotify//g')

    if [ "$status" = "Playing" ]; then
        echo "%{F#b4befe}󰎈%{F-} %{F#b4befe}${title:0:25}...%{F-}"
    elif [ "$status" = "Paused" ]; then
        echo "%{F#b4befe}󱋦 Paused%{F-}"
    else
        echo "%{F#b4befe}󰝚 No Media%{F-}"
    fi
done
