x = float(input("Δώσε έναν αριθμό: "))
y = float(input("Δώσε έναν αριθμό: "))
z = float(input("Δώσε έναν αριθμό: "))
average = (x + y + z) / 3
print(f"Ο μέσος όρος των τριών αριθμών είναι: {average}")