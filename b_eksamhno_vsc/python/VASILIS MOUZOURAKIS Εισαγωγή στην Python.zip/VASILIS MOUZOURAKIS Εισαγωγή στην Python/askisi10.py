first_number = float(input("Πρώτος αριθμός: "))
praksi = input("Πράξη (+, -, *, /): ")
second_number = float(input("Δεύτερος αριθμός: "))

if praksi == "+":
    result = first_number + second_number
elif praksi == "-":
    result = first_number - second_number
elif praksi == "*":
    result = first_number * second_number
elif praksi == "/":
    if second_number != 0:
        result = first_number / second_number
    else:
        print("Σφάλμα: Διαίρεση με το μηδέν")
        exit()
else:
    print("Σφάλμα: Άγνωστη πράξη")
    exit()

print(f"Αποτέλεσμα: {result}")