age = int(input("Δώσε την ηλικία σου: "))
print(f"Eίσαι {age} χρονών.")
