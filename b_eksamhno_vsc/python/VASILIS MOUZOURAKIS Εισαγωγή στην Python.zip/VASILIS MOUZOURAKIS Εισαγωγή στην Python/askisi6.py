grade = float(input("Δώσε την βαθμολογία σου: "))
if grade >= 50:
    print("Πέρασες!")
else:
    print("Κόπηκες!")