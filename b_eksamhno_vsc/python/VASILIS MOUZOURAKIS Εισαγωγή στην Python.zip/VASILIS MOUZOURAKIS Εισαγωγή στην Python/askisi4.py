number = float(input("Δώστε έναν αριθμό: "))
double = number * 2
print(f"Το διπλάσιο του {number} είναι {double}")