name = input("Δώσε το όνομά σου: ");
print(f"Γεια σου, {name}.")