x = float(input("Δώσε έναν αριθμό: "))
square = x ** 2
print(f"Το τετράγωνο του {x} είναι {square}")