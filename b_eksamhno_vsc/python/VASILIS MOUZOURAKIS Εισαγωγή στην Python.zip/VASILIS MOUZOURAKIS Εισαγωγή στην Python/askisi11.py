height = float(input("Δώσε το μήκος του ορθογωνίου: "))
width = float(input("Δώσε το πλάτος του ορθογωνίου: "))
perimeter = 2 * (height + width)
print(f"Η περίμετρος του ορθογωνίου είναι: {perimeter}")
area = height * width
print(f"Το εμβαδόν του ορθογωνίου είναι: {area}")