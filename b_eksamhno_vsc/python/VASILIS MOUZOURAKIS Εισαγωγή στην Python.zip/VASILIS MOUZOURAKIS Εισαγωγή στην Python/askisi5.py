number = int(input("Εισάγετε έναν αριθμό: "))

if number % 2 == 0:
    print(f"Ο αριθμός {number} είναι άρτιος")
else:
    print(f"Ο αριθμός {number} είναι περιττός")