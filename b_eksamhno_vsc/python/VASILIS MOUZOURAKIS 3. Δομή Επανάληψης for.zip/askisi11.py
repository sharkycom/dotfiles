total_all_trips = 0
expensive_trips_count = 0

for i in range(5):
    print(f"Στοιχεία για το ταξίδι {i+1}:")
     
    destination = input("Πόλη προορισμού: ")
    days = int(input("Αριθμός ημερών: "))
    daily_cost = float(input("Ημερήσιο κόστος (€): "))
    
    trip_total_cost = days * daily_cost
    total_all_trips += trip_total_cost
    
    print(f"Το συνολικό κόστος για το ταξίδι στην πόλη {destination} είναι {trip_total_cost:.2f}€")
    
    if daily_cost > 100:
        print("Χαρακτηρισμός: ΑΚΡΙΒΟ ΤΑΞΙΔΙ")
        expensive_trips_count += 1

print("-" * 30)
print(f"Συνολικό κόστος όλων των ταξιδιών: {total_all_trips:.2f}€")
print(f"Αριθμός ακριβών ταξιδιών: {expensive_trips_count}")