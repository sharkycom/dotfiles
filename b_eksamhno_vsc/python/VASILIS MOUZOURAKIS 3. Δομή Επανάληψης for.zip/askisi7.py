ginomeno = 1
for i in range(1, 6):
    ginomeno *= i
print("Το γινόμενο είναι:", ginomeno)