lexi = input("Δώσε μια λέξη: ")
for gramma in lexi:
    print(gramma)