lexi = input("Δώσε μια λέξη: ")
metritis = 0
for gramma in lexi:
    metritis += 1
print("Η λέξη έχει", metritis, "γράμματα.")