arithmos = int(input("Δώσε έναν αριθμό: "))
print(f"Πίνακας πολλαπλασιασμού του {arithmos}:")
for i in range(1, 11):
    print(f"{arithmos} x {i} = {arithmos * i}")
