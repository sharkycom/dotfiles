diathesima = 0
daneismena = 0

for i in range(5):
    print(f"Εισαγωγή στοιχείων για το βιβλίο {i+1}:")
    titlos = input("Τίτλος: ")
    syggrafeas = input("Συγγραφέας: ")
    katastasi = input("Κατάσταση (Διαθέσιμο/Δανεισμένο): ")
    meres = int(input("Ημέρες δανεισμού: "))

    if katastasi.lower() == "διαθέσιμο":
        diathesima += 1
    elif katastasi.lower() == "δανεισμένο":
        daneismena += 1
        if meres > 15:
            print(f"Το βιβλίο '{titlos}' πρέπει να επιστραφεί!")

print("-" * 20)
print(f"Σύνολο διαθέσιμων: {diathesima}")
print(f"Σύνολο δανεισμένων: {daneismena}")