athroisma = 0
for i in range(1, 101):
    athroisma += i
print("Το άθροισμα είναι:", athroisma)